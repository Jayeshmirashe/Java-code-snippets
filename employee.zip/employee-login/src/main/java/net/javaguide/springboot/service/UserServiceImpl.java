package net.javaguide.springboot.service;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import net.javaguide.springboot.model.Role;
import net.javaguide.springboot.model.User;
import net.javaguide.springboot.repository.UserRepository;
import net.javaguide.springboot.web.dto.UserRegistrationDto;

@Service
public class UserServiceImpl implements UserService{

	
	@Autowired
	private UserRepository userRepository;
	
	
	public UserServiceImpl(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}


	@Override
	public User save(UserRegistrationDto registrationDto) {
		User user= new User(registrationDto.getName(),
				registrationDto.getDateOfBirth(),registrationDto.getGender(),
				registrationDto.getAddress(),registrationDto.getCity(),
				registrationDto.getState(),registrationDto.getLoginId(),
				registrationDto.getPassword(),Arrays.asList(new Role("ROLE_USER")));
		
		return userRepository.save(user);
	}

}
