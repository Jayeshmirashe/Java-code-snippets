package net.javaguide.hibernate.model;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class })
public class EmployeeLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeLoginApplication.class, args);
	}

}
