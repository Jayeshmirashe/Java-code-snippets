package net.javaguide.hibernate.model;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
